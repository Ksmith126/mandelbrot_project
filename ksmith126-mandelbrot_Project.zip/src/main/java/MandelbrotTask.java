public class MandelbrotTask implements Runnable {
    private double x1, y1, x2, y2;
    private int startCol, endCol, startRow, endRow;
    private int[][] iterCounts;

	// TODO: Add constructor to set bounds for task
    public MandelbrotTask(double x1, double y1, double x2, double y2,
                          int startCol, int endCol, int startRow, int endRow,
                          int[][] iterCounts) {
                          	
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.startCol = startCol;
        this.endCol = endCol;
        this.startRow = startRow;
        this.endRow = endRow;
        this.iterCounts = iterCounts;
	
	}
	

	// Method to compute all iteration counts for region
	public void run() {
		// TODO: Loop over array extents to compute iterations for each point
			 for (int i = startRow; i < endRow; i++) {
			 	
            	for (int j = startCol; j < endCol; j++) {
                Complex c = getComplex(i, j);
                int iterCount = computeIterCount(c);
                iterCounts[i][j] = iterCount;
            	}
        	}
	}

	// Method to determine the number of iterations beginning with value c
	private int computeIterCount(Complex c) {
		int count = 0;
		// complex to store the result from previous iterations
		Complex result = new Complex(0,0);
		//if magnitude > 2 loop breaks
		boolean check = true;
		
			// loop to iterate the formula until magnitude > 2 or count = threshold		
			while(count < Mandelbrot.THRESHOLD && check == true){
				//if count = 0 result stays as 0
				if(count == 0){
					
				}
				else{
					result = result.mult(result).add(c);
					
				}
				if(result.getMagnitude() > 2){
					check = false;
				}
				
				count = count + 1;
			}
		
        
		return count;
	}
	
	// Method to determine the complex value from the bounds and array indicies
	private Complex getComplex(int row, int col) {
		Complex c;
		
		//given bounds are scaled to 800x800 and real is set to the distance from x axis
		double distFromX1 = ((x2-x1)/800)*col;
		double newReal = distFromX1 + x1;
		
		//distance from y2 is subtracted because for the array of 800 the top is 0
		double distFromY2 = ((y2-y1)/800)*row;
		double newImag = y2 - distFromY2;
		
		c = new Complex (newReal,newImag);
		return c;
	}
}
